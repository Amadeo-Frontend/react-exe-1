##
Exercício

Criar uma página HTML e com Javascript inserir 10 formas diferentes do texto "Hello World".Cada forma deve variar utilizando métodos nativos ou não do Javascript.Usar CSS para criar formas diferentes também é uma possibilidade, mas esgote as possibilidades com JS.

##